Panel skinning:

If you don't need the skinned panel comment out the 11th line in gtkrc!!!
